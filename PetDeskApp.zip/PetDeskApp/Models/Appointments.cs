﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace PetDeskApp.Models
{
    public class User
    {
        public int UserId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
    }

    public class Animal
    {
        public int AnimalId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string Species { get; set; }
        [DisplayFormat(NullDisplayText = "N/A")]
        public string Breed { get; set; }
    }

    public class Appointment
    {
        public int AppointmentId { get; set; }
        [Required]
        public string AppointmentType { get; set; }
        [Required]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yy HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime CreateDateTime { get; set; }
        [Required]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yy HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime RequestedDateTime { get; set; }
        [Required]
        public User User { get; set; }
        [Required]
        public Animal Animal { get; set; }
        public Boolean IsConfirm { get; set; } = false;
    }
}