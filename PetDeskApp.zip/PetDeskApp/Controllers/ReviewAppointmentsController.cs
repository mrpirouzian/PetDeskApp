﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PetDeskApp.Models;
using Newtonsoft.Json;

namespace PetDeskApp.Controllers
{
    public class ReviewAppointmentsController : Controller
    {
        string rawJSON = "";
        static List<Appointment> _appointments = new List<Appointment>();

        // GET: ReviewAppointments
        public ActionResult Index()
        {
            try
            {
                // Check to see if any appointment left, if No then get a new list
                if (_appointments.Count == 0)
                {
                    using (var webClient = new WebClient())
                        // ger a string representation of our JSON
                        rawJSON = webClient.DownloadString("https://stageapi.petdesk.com/api/SampleData/Appointments");

                    // Convert JSON stirng to series of objects
                    object ColcAppointments = JsonConvert.DeserializeObject<dynamic>(rawJSON);
                    dynamic response = JsonConvert.DeserializeObject(rawJSON);
                    _appointments = response.ToObject<List<Appointment>>();
                }

                // Make sure to display only appointments that are not confirmed!
                var model = from r in _appointments
                            where r.IsConfirm == false
                            orderby r.CreateDateTime
                            select r;

                return View(model);
            }
            catch
            {
                return View();
            }
        }

        // GET: ReviewAppointments/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ReviewAppointments/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ReviewAppointments/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here (if we need to creat an appointment right away)
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ReviewAppointments/Confirm/5
        public ActionResult Confirm(int id)
        {
            var appointment = _appointments.Single(r => r.AppointmentId == id);
            if (appointment == null)
            {
                return HttpNotFound();
            }
            appointment.IsConfirm = true;
            return View(_appointments);
        }

        // POST: ReviewAppointments/Confirm/5
        [HttpPost]
        public ActionResult Confirm(int id, FormCollection collection)
        {
            try
            {
                var appointment = _appointments.Single(r => r.AppointmentId == id);
                if (appointment == null)
                {
                    return HttpNotFound();
                }
                appointment.IsConfirm = true;
                if (TryUpdateModel(_appointments))
                {
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: ReviewAppointments/ModifyAppointment/5
        public ActionResult ModifyAppointment(int id)
        {
            var appointment = _appointments.Single(r => r.AppointmentId == id);
            if (appointment == null)
            {
                return HttpNotFound();
            }
            return View(appointment);
        }

        // POST: ReviewAppointments/ModifyAppointment/5
        [HttpPost]
        public ActionResult ModifyAppointment(int id, FormCollection collection)
        {
            try
            {
                var appointment = _appointments.Single(r => r.AppointmentId == id);
                if (appointment == null)
                {
                    return HttpNotFound();
                }
                appointment.IsConfirm = true;
                return TryUpdateModel(_appointments) ? RedirectToAction("Index") : (ActionResult)View(_appointments);
            }
            catch
            {
                return View();
            }
        }
    }
}