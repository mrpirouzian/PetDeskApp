﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PetDeskApp.Filters
{
    public class LogAttribute : ActionFilterAttribute
    {
        string _StrLogText = "===========================================" + Environment.NewLine + @"Date:" + DateTime.Now.ToString() + Environment.NewLine;
        string _strFilePath = @"C:\Logs\PDLoge.txt";

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            base.OnActionExecuted(filterContext);
            if (filterContext.Exception != null)
                System.IO.File.WriteAllText(_strFilePath, _StrLogText + filterContext.Exception.Message);
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            if (filterContext.Result != null)
                System.IO.File.WriteAllText(_strFilePath, _StrLogText + filterContext.Result.ToString());
        }
      
    }
}